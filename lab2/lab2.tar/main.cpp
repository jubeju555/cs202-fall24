/* 
judah benjamin 
interactive connect4 game 
prints out the board and adds the move you have made. 

sources cited: C++.com "tictactoe scaling to C4" was the name of the article
stack overflow: for quick typing errors and a reminder on what "not enough arguments means"
geeks4geeks: reminder on calling constructors
stackoverflow: meaning of errors
TA's: errors, printing out the display,setting the counters right, teaching how to cout your way to finding an error

*/
#include "C4Board.h"   // class definition for C4Board used below

int main() {
  C4Board c4;   // instantiate an instance of a C4Board object
  c4.play();    
   // play game!!
}

